SIMONYI ÖRS – SZEMÉLYES PORTFÓLIÓ WEBOLDAL

Tartalom:
- 6 aloldal: Kezdőlap, Rólam, Tanulmányok, Projektek, Motiváció, Kapcsolat
- Reszponzív megjelenés mobilon és asztali gépen
- Egyedi sötét, technológiai arculat
- Oldalankénti SEO title és description, Open Graph alapok, robots.txt és sitemap.xml
- Kapcsolati űrlap (Formspree végpont beállítása szükséges)
- Google Analytics 4 kódhely (GA4 mérési azonosító beállítása szükséges)

ÉLESÍTÉS ELŐTT:
1. Cseréld le a sajat-domain.hu címet a saját domainedre minden HTML-fájlban, a robots.txt-ben és a sitemap.xml-ben.
2. A HTML-fájlokban cseréld le a G-XXXXXXXXXX értéket a saját GA4 mérési azonosítódra.
3. A kapcsolat.html fájlban cseréld le az IDE_IRD_AZONOSITOD részt a Formspree űrlapazonosítódra.
4. Add meg a valódi e-mail-címedet, LinkedIn/GitHub profilodat.
5. A tanulmányok és projektek oldalon csak valós, ellenőrzött adatokat és saját munkákat tüntess fel.
6. Töltsd fel a mappa tartalmát egy statikus tárhelyre (pl. GitHub Pages, Netlify vagy saját tárhely).

Az analitika jelenleg helykitöltő mérőkóddal szerepel; a tényleges adatgyűjtés csak érvényes GA4-azonosítóval indul.
