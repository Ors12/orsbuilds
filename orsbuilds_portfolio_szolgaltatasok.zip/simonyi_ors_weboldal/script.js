
const menu = document.querySelector('.menu');
const links = document.querySelector('.links');

if (menu && links) {
  menu.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    menu.setAttribute('aria-expanded', String(open));
  });
}

const year = document.querySelector('#year');
if (year) year.textContent = new Date().getFullYear();

// Egységes, lépcsőzetes belépő animáció minden aloldalon.
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if (!reduceMotion) {
  const groups = [
    '.hero',
    '.page-head',
    '.section-head',
    '.grid',
    '.content',
    '.contact-grid',
    '.visual',
    '.actions'
  ];

  groups.forEach((selector) => {
    document.querySelectorAll(selector).forEach((group) => {
      const children = Array.from(group.children).filter((element) =>
        !element.matches('script, style')
      );

      children.forEach((element, index) => {
        element.classList.add('stagger-item');
        element.style.setProperty('--stagger-delay', `${index * 110}ms`);
      });
    });
  });

  // Egységes spin animáció a szövegdobozokon minden oldalon.
  document.querySelectorAll('.page-head, .content, .card, .visual, .field').forEach((element, index) => {
    element.classList.add('carousel-item', 'stagger-item');
    if (!element.style.getPropertyValue('--stagger-delay')) {
      element.style.setProperty('--stagger-delay', `${index * 110}ms`);
    }
  });

  // A kártyák és űrlapmezők külön-külön, egymás után jelennek meg.
  document.querySelectorAll('.grid > *, .contact-grid > *, form .field').forEach((element, index) => {
    element.classList.add('stagger-item');
    element.style.setProperty('--stagger-delay', `${index * 100}ms`);
  });

  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        currentObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -35px 0px' });

  document.querySelectorAll('.stagger-item').forEach((element) => observer.observe(element));
}
